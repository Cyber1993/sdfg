export interface ResendEmailConfirmationModel {
	email: string;
}
