export interface ISendFriendRequest {
	userId: string;
	friendId: string;
}
