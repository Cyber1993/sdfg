export interface IFeeling {
	id?: string;
	name: string;
	emoji: string;
}
