export enum Status {
    IDLE = 'idle',
    LOADING = 'loading',
    SUCCESS = 'completed',
    ERROR = 'error',
}