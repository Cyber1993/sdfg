namespace Facebook.Server.Http;

public class HttpContextItemKeys
{
    public const string Errors = "errors";
}