namespace Facebook.Domain.Post;

public class FeelingEntity
{
    public Guid Id { get; set; }
    public string Emoji { get; set; }
    public string Name { get; set; }
}