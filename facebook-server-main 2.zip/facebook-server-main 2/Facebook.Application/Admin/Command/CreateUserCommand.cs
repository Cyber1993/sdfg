namespace Facebook.Application.Admin.Command.CreateUser;

public record CreateUserCommand();